///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (colorChannels == 3)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		}
		else if (colorChannels == 4)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		}
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			stbi_image_free(image);
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

void SceneManager::SetupSceneLights()
{
	// Enable lighting
	m_pShaderManager->setIntValue("bUseLighting", true);

	// Light 0 - brighter main overhead light
	m_pShaderManager->setVec3Value("lightSources[0].position", 5.0f, 6.0f, 6.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.25f, 0.25f, 0.25f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.85f, 0.85f, 0.85f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.90f, 0.90f, 0.90f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.35f);

	// Light 1 - warm fill light
	m_pShaderManager->setVec3Value("lightSources[1].position", -4.0f, 3.0f, -2.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.08f, 0.07f, 0.06f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.35f, 0.30f, 0.24f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.25f, 0.22f, 0.18f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.15f);

	// Turn off unused lights
	for (int i = 2; i < 4; i++)
	{
		std::string index = std::to_string(i);

		m_pShaderManager->setVec3Value(("lightSources[" + index + "].position").c_str(), 0.0f, 0.0f, 0.0f);
		m_pShaderManager->setVec3Value(("lightSources[" + index + "].ambientColor").c_str(), 0.0f, 0.0f, 0.0f);
		m_pShaderManager->setVec3Value(("lightSources[" + index + "].diffuseColor").c_str(), 0.0f, 0.0f, 0.0f);
		m_pShaderManager->setVec3Value(("lightSources[" + index + "].specularColor").c_str(), 0.0f, 0.0f, 0.0f);
		m_pShaderManager->setFloatValue(("lightSources[" + index + "].focalStrength").c_str(), 1.0f);
		m_pShaderManager->setFloatValue(("lightSources[" + index + "].specularIntensity").c_str(), 0.0f);
	}
}

void SceneManager::SetDefaultMaterial()
{
	m_pShaderManager->setVec3Value("material.ambientColor", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setFloatValue("material.ambientStrength", 0.3f);
	m_pShaderManager->setVec3Value("material.diffuseColor", 0.7f, 0.7f, 0.7f);
	m_pShaderManager->setVec3Value("material.specularColor", 0.8f, 0.8f, 0.8f);
	m_pShaderManager->setFloatValue("material.shininess", 32.0f);
}
void SceneManager::SetFloorMaterial()
{
	m_pShaderManager->setVec3Value("material.ambientColor", 0.15f, 0.15f, 0.15f);
	m_pShaderManager->setFloatValue("material.ambientStrength", 0.2f);
	m_pShaderManager->setVec3Value("material.diffuseColor", 0.6f, 0.6f, 0.6f);
	m_pShaderManager->setVec3Value("material.specularColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setFloatValue("material.shininess", 64.0f);
}
void SceneManager::DrawFloor()
{
	glm::vec3 scaleXYZ = glm::vec3(20.0f, 1.0f, 12.0f);
	glm::vec3 positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetFloorMaterial();

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderTexture("floorTexture");
	SetTextureUVScale(6.0f, 4.0f);
	m_basicMeshes->DrawPlaneMesh();

	SetDefaultMaterial();
	SetTextureUVScale(1.0f, 1.0f);
}
/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/
void SceneManager::DrawTable()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	scaleXYZ = glm::vec3(8.0f, 0.4f, 5.0f);
	positionXYZ = glm::vec3(0.0f, 2.5f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("tableTopTexture");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(0.30f, 1.0f, 0.30f);

	positionXYZ = glm::vec3(-3.5f, 1.25f, 2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("tableLegTexture");
	m_basicMeshes->DrawCylinderMesh();

	positionXYZ = glm::vec3(3.5f, 1.25f, 2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("tableLegTexture");
	m_basicMeshes->DrawCylinderMesh();

	positionXYZ = glm::vec3(-3.5f, 1.25f, -2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("tableLegTexture");
	m_basicMeshes->DrawCylinderMesh();

	positionXYZ = glm::vec3(3.5f, 1.25f, -2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("tableLegTexture");
	m_basicMeshes->DrawCylinderMesh();

	SetTextureUVScale(1.0f, 1.0f);
	SetDefaultMaterial();
}

void SceneManager::DrawFruitBowl()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	scaleXYZ = glm::vec3(1.00f, 0.40f, 1.00f);
	positionXYZ = glm::vec3(-1.6f, 2.95f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_pShaderManager->setIntValue("bUseTexture", false);
	SetShaderColor(0.7f, 0.6f, 0.5f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	scaleXYZ = glm::vec3(0.30f, 0.30f, 0.30f);

	positionXYZ = glm::vec3(-1.90f, 3.35f, 0.15f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.98f, 0.75f, 0.15f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	positionXYZ = glm::vec3(-1.45f, 3.35f, -0.10f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.90f, 0.65f, 0.08f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	positionXYZ = glm::vec3(-1.65f, 3.35f, 0.35f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.96f, 0.80f, 0.20f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	positionXYZ = glm::vec3(-1.30f, 3.35f, 0.15f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.85f, 0.60f, 0.05f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	positionXYZ = glm::vec3(-1.55f, 3.45f, 0.00f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.97f, 0.76f, 0.18f, 1.0f);
	m_basicMeshes->DrawSphereMesh();
}
void SceneManager::DrawVaseArrangement()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	/******************** VASE *******************/
	scaleXYZ = glm::vec3(0.40f, 1.00f, 0.40f);
	positionXYZ = glm::vec3(1.6f, 3.05f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_pShaderManager->setIntValue("bUseTexture", false);
	SetShaderColor(0.92f, 0.92f, 0.95f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	/******************* STEMS *******************/

	scaleXYZ = glm::vec3(0.05f, 0.60f, 0.05f);
	positionXYZ = glm::vec3(1.45f, 3.75f, 0.00f);
	SetTransformations(scaleXYZ, -10.0f, 0.0f, 10.0f, positionXYZ);
	SetShaderColor(0.18f, 0.55f, 0.22f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	scaleXYZ = glm::vec3(0.05f, 0.65f, 0.05f);
	positionXYZ = glm::vec3(1.60f, 3.80f, 0.10f);
	SetTransformations(scaleXYZ, 5.0f, 0.0f, -8.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	scaleXYZ = glm::vec3(0.05f, 0.62f, 0.05f);
	positionXYZ = glm::vec3(1.75f, 3.75f, -0.08f);
	SetTransformations(scaleXYZ, 8.0f, 0.0f, 12.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	scaleXYZ = glm::vec3(0.05f, 0.58f, 0.05f);
	positionXYZ = glm::vec3(1.55f, 3.70f, -0.18f);
	SetTransformations(scaleXYZ, -6.0f, 0.0f, -10.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	/******************* FLOWERS *****************/

	scaleXYZ = glm::vec3(0.25f);
	positionXYZ = glm::vec3(1.35f, 4.25f, 0.00f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.98f, 0.85f, 0.10f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	positionXYZ = glm::vec3(1.58f, 4.38f, 0.18f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawSphereMesh();

	positionXYZ = glm::vec3(1.82f, 4.24f, -0.16f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawSphereMesh();

	positionXYZ = glm::vec3(1.48f, 4.12f, -0.28f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawSphereMesh();

	positionXYZ = glm::vec3(1.72f, 4.18f, 0.30f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawSphereMesh();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	// Milestone Four Enhancements:
	// 1. Applied a tiled wood texture to the tabletop for a more realistic appearance.
	// 2. Applied a separate texture to the table legs to create a cohesive multi-shape object.
	// 3. Applied a repeating floor texture to improve overall scene detail.
	// 4. Used UV scaling to avoid stretched textures and improve visual quality.

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();

	// Load texture images
	CreateGLTexture("Debug/floor.jpg", "floorTexture");
	CreateGLTexture("Debug/table_top.jpg", "tableTopTexture");
	CreateGLTexture("Debug/table_top.jpg", "tableLegTexture");
	// Bind loaded textures to OpenGL texture slots
	BindGLTextures();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	SetupSceneLights();
	SetDefaultMaterial();

	DrawFloor();
	DrawTable();
	DrawFruitBowl();
	DrawVaseArrangement();
}
	
	/*********************************************/
	/****************************************************************/

