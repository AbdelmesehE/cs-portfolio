package com.example.ehababdelmeseh_modulethree;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    private EditText editTextItemName;
    private EditText editTextQuantity;
    private Button buttonAddItem;
    private Button buttonUpdateItem;
    private Button buttonDeleteItem;
    private Button buttonLogout;
    private Button buttonGoToSms;
    private GridView listViewInventory;

    private DatabaseHelper databaseHelper;
    private ArrayList<String> itemList;
    private ArrayAdapter<String> adapter;

    private int selectedItemId = -1;
    private String smsPhoneNumber = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        editTextItemName = findViewById(R.id.editTextItemName);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonUpdateItem = findViewById(R.id.buttonUpdateItem);
        buttonDeleteItem = findViewById(R.id.buttonDeleteItem);
        buttonLogout = findViewById(R.id.buttonLogout);
        buttonGoToSms = findViewById(R.id.buttonGoToSms);
        listViewInventory = findViewById(R.id.listViewInventory);

        databaseHelper = new DatabaseHelper(this);

        itemList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, R.layout.grid_item, itemList);
        listViewInventory.setAdapter(adapter);

        loadItems();

        buttonAddItem.setOnClickListener(view -> {
            String itemName = editTextItemName.getText().toString().trim();
            String quantityText = editTextQuantity.getText().toString().trim();

            if (itemName.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(this, "Please enter item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityText);
            boolean inserted = databaseHelper.addItem(itemName, quantity);

            if (inserted) {
                Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();

                if (quantity <= 5) {
                    sendLowInventoryAlert(itemName, quantity);
                }

                clearFields();
                loadItems();
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        });

        listViewInventory.setOnItemClickListener((parent, view, position, id) -> {
            String item = itemList.get(position);

            String[] parts = item.split("\\|");
            selectedItemId = Integer.parseInt(parts[0].replace("ID:", "").trim());
            String itemName = parts[1].trim();
            String quantity = parts[2].replace("Qty:", "").trim();

            editTextItemName.setText(itemName);
            editTextQuantity.setText(quantity);

            Toast.makeText(this, "Item selected", Toast.LENGTH_SHORT).show();
        });

        buttonUpdateItem.setOnClickListener(view -> {
            if (selectedItemId == -1) {
                Toast.makeText(this, "Please select an item to update", Toast.LENGTH_SHORT).show();
                return;
            }

            String itemName = editTextItemName.getText().toString().trim();
            String quantityText = editTextQuantity.getText().toString().trim();

            if (itemName.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(this, "Please enter item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityText);
            boolean updated = databaseHelper.updateItem(selectedItemId, itemName, quantity);

            if (updated) {
                Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show();

                if (quantity <= 5) {
                    sendLowInventoryAlert(itemName, quantity);
                }

                clearFields();
                loadItems();
            } else {
                Toast.makeText(this, "Failed to update item", Toast.LENGTH_SHORT).show();
            }
        });

        buttonDeleteItem.setOnClickListener(view -> {
            if (selectedItemId == -1) {
                Toast.makeText(this, "Please select an item to delete", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean deleted = databaseHelper.deleteItem(selectedItemId);

            if (deleted) {
                Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
                clearFields();
                loadItems();
            } else {
                Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
            }
        });

        buttonLogout.setOnClickListener(view -> {
            Intent intent = new Intent(InventoryActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        buttonGoToSms.setOnClickListener(view -> {
            Intent intent = new Intent(InventoryActivity.this, SmsActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (SmsActivity.savedPhoneNumber != null) {
            smsPhoneNumber = SmsActivity.savedPhoneNumber;
        }
    }

    private void loadItems() {
        itemList.clear();
        Cursor cursor = databaseHelper.getAllItems();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                int quantity = cursor.getInt(2);

                itemList.add("ID: " + id + " | " + name + " | Qty: " + quantity);
            } while (cursor.moveToNext());

            cursor.close();
        }

        adapter.notifyDataSetChanged();
    }

    private void clearFields() {
        editTextItemName.setText("");
        editTextQuantity.setText("");
        selectedItemId = -1;
    }

    private void sendLowInventoryAlert(String itemName, int quantity) {
        if (smsPhoneNumber == null || smsPhoneNumber.isEmpty()) {
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(
                        smsPhoneNumber,
                        null,
                        "Low inventory alert: " + itemName + " has quantity " + quantity,
                        null,
                        null
                );
                Toast.makeText(this, "Low inventory SMS sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "SMS failed to send", Toast.LENGTH_SHORT).show();
            }
        }
    }
}