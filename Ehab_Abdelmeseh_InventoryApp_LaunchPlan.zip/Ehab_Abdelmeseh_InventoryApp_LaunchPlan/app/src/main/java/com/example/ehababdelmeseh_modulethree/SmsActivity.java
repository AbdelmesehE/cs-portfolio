package com.example.ehababdelmeseh_modulethree;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private EditText editTextPhoneNumber;
    private Button buttonRequestPermission;
    private Button buttonSavePhone;

    public static String savedPhoneNumber = "";

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    Toast.makeText(SmsActivity.this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SmsActivity.this, "SMS permission denied. App still works without SMS.", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        editTextPhoneNumber = findViewById(R.id.editTextPhoneNumber);
        buttonRequestPermission = findViewById(R.id.buttonRequestPermission);
        buttonSavePhone = findViewById(R.id.buttonSavePhone);

        editTextPhoneNumber.setText(savedPhoneNumber);

        buttonRequestPermission.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
            } else {
                requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        buttonSavePhone.setOnClickListener(view -> {
            String phone = editTextPhoneNumber.getText().toString().trim();

            if (phone.isEmpty()) {
                Toast.makeText(this, "Please enter a phone number", Toast.LENGTH_SHORT).show();
                return;
            }

            savedPhoneNumber = phone;
            Toast.makeText(this, "Phone number saved", Toast.LENGTH_SHORT).show();
        });
    }
}